# QA Automation Framework — Multi-Tenant Playwright + Python

## 📁 Structure
- `config/`     — Base config and per-tenant JSON environments
- `pages/`      — Page Object Model (common + tenant-specific pages)
- `tests/`      — Test files organized by tenant
- `utils/`      — Browser factory, API client, data generator, logger
- `test_data/`  — JSON test data per tenant
- `reports/`    — Auto-generated reports and logs

## ▶️ Running Tests

```bash
# Install dependencies
pip install -r requirements.txt
playwright install

# Run TenantA tests
pytest tests/tenant_a/ --tenant=tenant_a

# Run TenantB on Firefox
pytest tests/tenant_b/ --tenant=tenant_b --browser=firefox

# Run smoke tests only
pytest -m smoke --tenant=tenant_a
```

## 🧱 Key Concepts
- **BasePage**       — shared methods for all pages
- **TenantConfig**   — loads tenant-specific URL and credentials
- **BrowserFactory** — creates browser instances cleanly
- **conftest.py**    — layered fixtures (global → tenant-level)
