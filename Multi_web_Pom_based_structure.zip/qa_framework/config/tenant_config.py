import json
import os

class TenantConfig:
    def __init__(self, tenant: str):
        path = os.path.join(os.path.dirname(__file__), f"environments/{tenant}.json")
        with open(path) as f:
            data = json.load(f)
        self.base_url = data["base_url"]
        self.credentials = data["credentials"]
        self.tenant_name = tenant

    def get_credential(self, role: str) -> dict:
        return self.credentials.get(role, {})
