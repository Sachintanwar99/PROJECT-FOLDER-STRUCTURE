class BaseConfig:
    TIMEOUT = 30000
    HEADLESS = False
    SLOW_MO = 0
    BROWSER = "chrome"
    SCREENSHOT_ON_FAILURE = True
    VIDEO_ON_FAILURE = False
