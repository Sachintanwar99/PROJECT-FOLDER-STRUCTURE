from pages.common.login_page import LoginPage
from pages.common.dashboard_page import DashboardPage

def test_admin_login(page, config):
    login = LoginPage(page, config)
    login.login_as_admin()
    dashboard = DashboardPage(page, config)
    assert dashboard.is_loaded(), "Dashboard should be visible after admin login"

def test_invalid_login(page, config):
    login = LoginPage(page, config)
    login.login("wrong_user", "wrong_pass")
    assert login.get_error_message() == "Invalid credentials"

def test_user_login(page, config):
    login = LoginPage(page, config)
    login.login_as_user()
    dashboard = DashboardPage(page, config)
    assert dashboard.is_loaded(), "Dashboard should be visible after user login"
