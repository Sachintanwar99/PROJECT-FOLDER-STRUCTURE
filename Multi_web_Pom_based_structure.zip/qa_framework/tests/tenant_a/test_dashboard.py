from pages.common.dashboard_page import DashboardPage

def test_dashboard_loads(logged_in_page, config):
    dashboard = DashboardPage(logged_in_page, config)
    assert dashboard.is_loaded(), "Dashboard title should be visible"

def test_dashboard_logout(logged_in_page, config):
    dashboard = DashboardPage(logged_in_page, config)
    dashboard.logout()
    assert "login" in logged_in_page.url
