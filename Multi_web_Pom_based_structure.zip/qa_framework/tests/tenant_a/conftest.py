import pytest
from pages.common.login_page import LoginPage

@pytest.fixture(scope="function")
def logged_in_page(page, config):
    login = LoginPage(page, config)
    login.login_as_admin()
    return page
