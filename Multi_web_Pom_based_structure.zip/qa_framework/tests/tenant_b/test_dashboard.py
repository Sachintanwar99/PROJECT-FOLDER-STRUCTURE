from pages.common.dashboard_page import DashboardPage

def test_dashboard_loads(logged_in_page, config):
    dashboard = DashboardPage(logged_in_page, config)
    assert dashboard.is_loaded()
