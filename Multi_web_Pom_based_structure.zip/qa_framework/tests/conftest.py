import pytest
from playwright.sync_api import sync_playwright
from config.tenant_config import TenantConfig
from utils.browser_factory import BrowserFactory

def pytest_addoption(parser):
    parser.addoption("--tenant",  default="tenant_a", help="Tenant: tenant_a or tenant_b")
    parser.addoption("--browser", default="chrome",   help="Browser: chrome, firefox, safari")

@pytest.fixture(scope="session")
def tenant(request):
    return request.config.getoption("--tenant")

@pytest.fixture(scope="session")
def config(tenant):
    return TenantConfig(tenant)

@pytest.fixture(scope="session")
def browser_instance(request):
    with sync_playwright() as p:
        browser = BrowserFactory.get_browser(p, request.config.getoption("--browser"))
        yield browser
        browser.close()

@pytest.fixture(scope="function")
def page(browser_instance):
    context = browser_instance.new_context()
    page = context.new_page()
    yield page
    context.close()
