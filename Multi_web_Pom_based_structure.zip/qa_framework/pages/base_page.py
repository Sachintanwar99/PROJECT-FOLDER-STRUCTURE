import os
from datetime import datetime

class BasePage:
    def __init__(self, page, config):
        self.page = page
        self.config = config

    def navigate(self, path=""):
        self.page.goto(self.config.base_url + path)

    def take_screenshot(self, name="screenshot"):
        os.makedirs("reports", exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.page.screenshot(path=f"reports/{name}_{timestamp}.png")

    def wait_for_page_load(self):
        self.page.wait_for_load_state("networkidle")

    def is_element_visible(self, locator) -> bool:
        return self.page.locator(locator).is_visible()
