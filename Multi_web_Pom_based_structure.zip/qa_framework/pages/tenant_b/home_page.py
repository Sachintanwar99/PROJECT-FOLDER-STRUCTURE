from pages.base_page import BasePage

class TenantBHomePage(BasePage):
    def __init__(self, page, config):
        super().__init__(page, config)
        self.welcome_banner = page.locator(".tenant-b-welcome")
        self.sidebar        = page.locator(".sidebar")

    def navigate_to_home(self):
        self.navigate("/home")

    def is_sidebar_visible(self) -> bool:
        return self.sidebar.is_visible()
