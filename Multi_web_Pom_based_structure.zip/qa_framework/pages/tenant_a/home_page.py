from pages.base_page import BasePage

class TenantAHomePage(BasePage):
    def __init__(self, page, config):
        super().__init__(page, config)
        self.welcome_banner = page.locator(".tenant-a-welcome")
        self.feature_panel  = page.locator(".feature-panel")

    def navigate_to_home(self):
        self.navigate("/home")

    def is_welcome_banner_visible(self) -> bool:
        return self.welcome_banner.is_visible()
