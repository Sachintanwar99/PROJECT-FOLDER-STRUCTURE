from pages.base_page import BasePage

class TenantASettingsPage(BasePage):
    def __init__(self, page, config):
        super().__init__(page, config)
        self.settings_header = page.locator(".settings-header")
        self.save_button     = page.locator("#save-settings")

    def navigate_to_settings(self):
        self.navigate("/settings")

    def save_settings(self):
        self.save_button.click()
        self.wait_for_page_load()
