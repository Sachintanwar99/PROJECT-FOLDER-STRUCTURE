from pages.base_page import BasePage

class LoginPage(BasePage):
    def __init__(self, page, config):
        super().__init__(page, config)
        self.username_input = page.locator("#username")
        self.password_input = page.locator("#password")
        self.login_button   = page.locator("#login-btn")
        self.error_message  = page.locator(".error-msg")

    def login(self, username: str, password: str):
        self.navigate("/login")
        self.username_input.fill(username)
        self.password_input.fill(password)
        self.login_button.click()
        self.wait_for_page_load()

    def login_as_admin(self):
        creds = self.config.get_credential("admin")
        self.login(creds["username"], creds["password"])

    def login_as_user(self):
        creds = self.config.get_credential("user")
        self.login(creds["username"], creds["password"])

    def get_error_message(self) -> str:
        return self.error_message.inner_text()
