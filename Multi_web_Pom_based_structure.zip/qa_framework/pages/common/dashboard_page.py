from pages.base_page import BasePage

class DashboardPage(BasePage):
    def __init__(self, page, config):
        super().__init__(page, config)
        self.dashboard_title = page.locator(".dashboard-title")
        self.logout_button   = page.locator("#logout-btn")
        self.nav_menu        = page.locator(".nav-menu")

    def is_loaded(self) -> bool:
        return self.dashboard_title.is_visible()

    def logout(self):
        self.logout_button.click()
        self.wait_for_page_load()

    def get_title(self) -> str:
        return self.dashboard_title.inner_text()
