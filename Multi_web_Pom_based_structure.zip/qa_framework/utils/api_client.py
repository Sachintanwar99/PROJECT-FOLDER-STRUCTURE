import requests

class APIClient:
    def __init__(self, config):
        self.base_url = config.base_url
        self.session = requests.Session()
        self.token = None

    def login(self, username: str, password: str):
        response = self.session.post(
            f"{self.base_url}/api/auth/login",
            json={"username": username, "password": password}
        )
        response.raise_for_status()
        self.token = response.json().get("token")
        self.session.headers.update({"Authorization": f"Bearer {self.token}"})
        return self.token

    def get(self, endpoint: str) -> dict:
        response = self.session.get(f"{self.base_url}{endpoint}")
        response.raise_for_status()
        return response.json()

    def post(self, endpoint: str, payload: dict) -> dict:
        response = self.session.post(f"{self.base_url}{endpoint}", json=payload)
        response.raise_for_status()
        return response.json()
