import logging
import os

def get_logger(name: str) -> logging.Logger:
    os.makedirs("reports", exist_ok=True)
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        console = logging.StreamHandler()
        console.setLevel(logging.INFO)
        console.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))

        file_handler = logging.FileHandler("reports/test_run.log")
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))

        logger.addHandler(console)
        logger.addHandler(file_handler)

    return logger
