from config.base_config import BaseConfig

class BrowserFactory:
    @staticmethod
    def get_browser(playwright, browser_type: str = BaseConfig.BROWSER):
        browsers = {
            "chrome":  playwright.chromium,
            "firefox": playwright.firefox,
            "safari":  playwright.webkit
        }
        if browser_type not in browsers:
            raise ValueError(f"Unsupported browser: {browser_type}. Choose from {list(browsers.keys())}")
        return browsers[browser_type].launch(
            headless=BaseConfig.HEADLESS,
            slow_mo=BaseConfig.SLOW_MO
        )
