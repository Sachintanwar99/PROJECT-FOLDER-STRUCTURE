import random
import string
from datetime import datetime

class DataGenerator:
    @staticmethod
    def random_string(length: int = 8) -> str:
        return ''.join(random.choices(string.ascii_lowercase, k=length))

    @staticmethod
    def random_email() -> str:
        return f"test_{DataGenerator.random_string()}@example.com"

    @staticmethod
    def random_phone() -> str:
        return f"+91{''.join(random.choices(string.digits, k=10))}"

    @staticmethod
    def timestamp() -> str:
        return datetime.now().strftime("%Y%m%d_%H%M%S")
